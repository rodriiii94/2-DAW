<?php
class IndexController {
    public function index() {
        require_once 'view/index.php';
    }
}