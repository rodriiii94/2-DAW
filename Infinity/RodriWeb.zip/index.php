<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Índice de Prácticas</title>
    <style>
        /* Estilos generales del cuerpo */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #eef2f6;
            color: #2c3e50;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* container principal */
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 450px;
            width: 100%;
            transition: transform 0.3s ease;
        }

        .container:hover {
            transform: translateY(-5px);
        }

        /* Estilos para el título */
        h1 {
            color: #34495e;
            margin-bottom: 25px;
            font-size: 28px;
            letter-spacing: 1px;
        }

        /* Estilos para la lista */
        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin: 15px 0;
        }

        /* Estilos para los enlaces */
        a {
            text-decoration: none;
            color: #3498db;
            font-size: 20px;
            font-weight: 500;
            padding: 10px 20px;
            border: 2px solid transparent;
            border-radius: 6px;
            transition: background-color 0.3s, border-color 0.3s;
        }

        a:hover {
            background-color: #3498db;
            color: #fff;
            border-color: #3498db;
        }

        /* Animación suave al cargar la página */
        .container {
            opacity: 0;
            animation: fadeIn 1s forwards;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Índice de Prácticas</h1>
        <ul>
            <li><a href="conversor.php">Conversor de monedas</a></li>
            <li><a href="capital.php">Capitales del mundo</a></li>
            <li><a href="banco/indexBanco.php">Web de un Banco</a></li>
        </ul>
    </div>
</body>
</html>

